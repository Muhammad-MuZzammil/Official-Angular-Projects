export const environment = {
  production: true,
  // api_url: 'http://192.168.8.22/unforgettable_travel/api/v1',
  // api_url: 'http://stagingwebsite.biz/php/unforgettable3/api/v1',
  api_url: 'https://unforgettabletravelcompany.com/ufg-form/api/v1',
  // api_url: 'https://unforgettabletravelcompany.com/staging-form/api/v1',



};
